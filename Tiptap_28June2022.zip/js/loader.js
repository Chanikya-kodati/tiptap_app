// JavaScript Document

$(window).ready(function(){	
	$('body').jpreLoader({
		splashID:"#jSplash",
		loaderVPos:'70%',
		autoClose:true,
		closeBtnText:"Let's Begin!",
		splashFunction:function(){}
	}, function() {
		//$('header,section,.innerpages,footer,.whatsapp').animate({'opacity':1});
		
		
		
	});
	//addRemoveStyle()
});

